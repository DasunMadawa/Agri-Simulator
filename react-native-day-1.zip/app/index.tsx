import { Button, Image, StyleSheet, Text, View } from "react-native";

export default function Index() {
  return (
    <View
      style={{
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Text className="text-blue-400" style={styles.nameText}>Edit app/index.tsx to edit this screen.</Text>
      <Button
        
        title="Learn More"
        color="#841584"
        accessibilityLabel="Learn more about this purple button"
      />
      <Image
        style={styles.reactLogo}
        source={require('@/assets/images/react-logo.png')}
      />
    </View>

  );
}

const styles = StyleSheet.create({
  nameText: {
    fontSize: 30
  },
  reactLogo: {
    height:100
  }
});

